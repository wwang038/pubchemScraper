x = 5
def addFive(integer):
    global x
    x+= integer

print(x)
addFive(3)
print(x)
addFive(6)

print(x)